#ifndef ADD_VALUE_H
#define ADD_VALUE_H

extern long add_value(long a, long b);

#endif /* ADD_VALUE_H */

