#ifndef ADD_VALUE_H
#define ADD_VALUE_H

#ifdef __cplusplus
extern "C"
{
#endif
	extern long add_value(long a, long b);
#ifdef __cplusplus
}
#endif

#endif /* ADD_VALUE_H */

