#ifndef STRFUNC_H
#define STRFUNC_H

#ifdef __cplusplus
extern "C"
{
#endif
	extern char *my_strend(char *str);

	extern long my_strlen(char *str);
#ifdef __cplusplus
}
#endif

#endif /* STRFUNC_H */

